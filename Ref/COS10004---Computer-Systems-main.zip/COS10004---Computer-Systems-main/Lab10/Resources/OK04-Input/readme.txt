OK4-GPIO3A-2.asm
Reads GPIO10, flashes LED 1 (GPIO18) or LED 2 (GPIO 23) depening on voltage on Pin 19 (GPIO 10), 
included timer function. 